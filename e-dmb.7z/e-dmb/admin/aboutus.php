<?php
 include('security.php');
 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/content.php');
?>

<!-- Modal -->
<div class="modal fade" id="addaboutus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="codeaboutus.php" method="POST">

            <div class="modal-body">
            <div class="form-group">
                    <label>Titel</label>
                    <input type="text" name="title" class="form-control" placeholder="Masukkan titel" required>
                </div>
                <div class="form-group">
                    <label>Sub Title</label>
                    <input type="text" name="subtitle" class="form-control" placeholder="Masukkan Sub Title" required>
                </div>
                <div class="form-group">
                    <label>Deskripsi</label>
                   <textarea type="text" name="deskripsi" class="form-control" placeholder="Masukkan Deskripsi"> </textarea>
                </div>
                <div class="form-group">
                    <label>Links</label>
                    <input type="text" name="links"  class="form-control" placeholder="Masukkan Links"required>
                </div>
        
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" name="aboutus_btn" class="btn btn-primary">SIMPAN</button>
            </div>
        </form>
    </div>
  </div>
</div>

<div class="container-fluid">

    
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">About Us
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addaboutus">
                ADD
            </button>
        </h6>
    </div>
</div>

<div class="card-body">

    <?php
        if(isset($_SESSION['success']) && $_SESSION['success'] !='')
        {
            echo '<h2>'.$_SESSION['success'].'</h2>';
            unset($_SESSION['success']);
        }

        if(isset($_SESSION['status']) && $_SESSION['status'] !='')
        {
            echo '<h2>'.$_SESSION['status'].'</h2>';
            unset($_SESSION['status']);
        }

    ?>

    <div class="table-responsive">

        <?php
            
            $query= "SELECT*FROM aboutus";
            $query_run = mysqli_query($connection, $query);
        ?>

        <table class="table table-bordered" id="dataTable" widht="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Sub Title</th>
                    <th>Deskripsi</th>
                    <th>Links</th>
                    <th>EDIT</th>
                    <th>Hapus </th>
                    
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>
