

<?php
        include('security.php');
       
       $query= "SELECT  data_entry.HARI_CENTER_MEETING, data_entry.TANGGAL_TAGIHAN, data_entry.CABANG, data_entry.KDWIL, data_entry.KD_UNIT, data_entry.KD_CENTER, data_entry.NAMA_UNIT, data_entry.NAMA_CENTER  FROM data_entry LEFT JOIN export_entry ON data_entry.id_entry=export_entry.id_entry WHERE data_entry.id_entry=export_entry.id_entry ";
       $query_run = mysqli_query($connection, $query);
       $developer_records= array();
       while ($rows= mysqli_fetch_assoc($query_run)){
            $developer_records[]= $rows;
       }
   ?>
   <div class="container" >
       
   <div class="well-sm col-sm-12">
        <div class="btn-group pull-right">
            <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
                <button type="submit" name="export-excel" class="btn btn-warning" value="Export-Excel"></button>
            </form>
        </div>
    </div>    

    <table class="table table-bordered" id="dataTable" widht="100%" cellspacing="0" role="grid">
        <thead>
            <tr>
                
                <th>HARI_CENTER_MEETING</th>
                <th>TANGGAL_TAGIHAN</th>
                <th>CABANG</th>
                <th>KDWIL</th>
                <th>KD_UNIT</th>
                <th>KD_CENTER</th>
                <th>NAMA_UNIT</th>
                <th>NAMA_CENTER</th>
               
            </tr>
        </thead>
        
        
        <tbody>
       
        
            <?php
                foreach($developer_records as $_row){        
            ?>

             
            <tr> 
             
               <td><?php echo $_row['HARI_CENTER_MEETING'];?></td>
               <td><?php echo $_row['TANGGAL_TAGIHAN'];?></td>
               <td><?php echo $_row['CABANG'];?></td>
               <td><?php echo $_row['KDWIL'];?></td>
               <td><?php echo $_row['KD_UNIT'];?></td>
               <td><?php echo $_row['KD_CENTER'];?></td>
               <td><?php echo $_row['NAMA_UNIT'];?></td>
               <td><?php echo $_row['NAMA_CENTER'];?></td>
              
                    
            </tr>
            
            <?php
                    }
                ?>

        </tbody>
    </table>

    <?php
    
       
    if(isset($_POST['export-excel'])){
    $fileName= "offpayment_export_".date('Ymd') . ".xls";
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:attachment; filename=".$fileName."");
    
    $showColoumn= false;
    if(!empty($developer_records)){
        foreach($developer_records as $_row){
            if(!$showColoumn){
                $query="TRUNCATE TABLE export_entry";
                $query_run= mysqli_query($connection, $query);
            $showColoumn=false;
            }
                
        }
    }
    exit;
}
?>

