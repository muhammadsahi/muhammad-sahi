<?php
session_start();
include('config.php');

$npsn= $_SESSION['username'];
$update= mysqli_query($connection, "UPDATE users SET status= '0' WHERE username= '$npsn'");

if($update)
{
    session_destroy();
   
    header ('location: ../index.php');
}

?>