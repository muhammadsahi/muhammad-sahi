<?php
include('security.php');


if(isset($_POST['export-excel'])){
    $fileName= "offpayment_export_".date('Ymd') . ".xls";
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:attachment; filename=".$fileName."");
    
    $showColoumn= false;
    if(!empty($developer_records)){
        foreach($developer_records as $_row){
            if(!$showColoumn){
                echo implode("\t", array_keys($_row)) . "\n";
            $showColoumn=true;
            }
                echo implode("\t", array_values($_row)) . "\n";
        }
    }
    exit;
}

?>