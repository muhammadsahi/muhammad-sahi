<?php
 include('security.php');

 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/content.php');
?>


  <!-- Begin Page Content -->
  <div class="container-fluid">

<!-- Page Heading -->
<div class="card shadow mb-4">
<div class="card-header py-3">
<H5>Dashboard</H5>

</div>

&nbsp;

      <!-- Content Row -->
      <div class="row"> &emsp;

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
          <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
              <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                  <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Jumlah Data Admin</div>
                  <div class="h5 mb-0 font-weight-bold text-gray-800">
                    <?php
                      

                      $query= "SELECT nip FROM users ORDER BY nip";
                      $query_run= mysqli_query($connection, $query);

                      $row= mysqli_num_rows($query_run);
                      echo '<h5>Total Admin: '.$row.'</h5>';

                    ?>
                    
                  </div>&nbsp;<a href="">See mores...</a>
                </div>
                <div class="col-auto">
                  <i class="fas fa-users fa-2x text-gray-300"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
          <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
              <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                  <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Jumlah Data Entry</div>
                  <div class="h5 mb-0 font-weight-bold text-gray-800">

                  <?php
                      

                      $query= "SELECT id_entry FROM data_entry ORDER BY id_entry";
                      $query_run= mysqli_query($connection, $query);

                      $row= mysqli_num_rows($query_run);
                      echo '<h5>Total Entry: '.$row.'</h5>';

                    ?>

                  </div>&nbsp;<a href="">See mores...</a>
                </div>
                <div class="col-auto">
                  <i class="fas fa-folder-open fa-2x text-gray-300"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
          <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
              <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Jumlah Input entry</div>
                  <div class="row no-gutters align-items-center">
                    <div class="col-auto">
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                      <?php
                      

                      $query= "SELECT id_export FROM export_entry ORDER BY id_export";
                      $query_run= mysqli_query($connection, $query);

                      $row= mysqli_num_rows($query_run);
                      echo '<h5>Input Entry: '.$row.'</h5>';

                    ?>
                      </div>&nbsp;<a href="">See mores...</a>
                    </div>
                    <div class="col">
                    </div>
                  </div>
                </div>
                <div class="col-auto">
                  <i class="fas fa-folder fa-2x text-gray-300"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

      
  </div>
  </div>





<?php
  include('includes/scripts.php');
  include('includes/footer.php');
?>
