<?php
 include('security.php');
 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/content.php');
 ?>

<!-- Modal -->
<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="add.php" method="POST">

            <div class="modal-body">
            <div class="form-group">
                    <label>NIP</label>
                    <input type="text" name="nip" class="form-control" placeholder="Masukkan NIP" required>
                </div>
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="nama" class="form-control" placeholder="Masukkan Nama" required>
                </div>
                <div class="form-group">
                    <label>Jabatan</label>
                    <input type="text" name="jabatan" class="form-control" placeholder="Nama Jabatan"required>
                </div>
                <div class="form-group">
                    <label>Username</label>
                    <input type="username" name="username"  class="form-control" placeholder="NIP"required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Masukkan Password"required>
                </div>
                <div class="form-group">
                    <label>status</label>
                    <input type="text" name="status" class="form-control" placeholder="Masukkan No.HP"required>
                </div>
                <div class="form-group">
                <label>Select Level</label>
                    <select class="form-control" name="level"required>
                        <option value="">Pilih Level</option>
                        <option value="admin">Administrator</option>
                        <option value="operator">Operator</option>
                    </select>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" name="registerbtn" class="btn btn-primary">SIMPAN</button>
            </div>
        </form>
    </div>
  </div>
</div>

<div class="container-fluid">

    
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Admin profile
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
                Tambah Data User
            </button>
        </h6>
    </div>

<div class="card-body">

<?php
    if(isset($_SESSION['success']) && $_SESSION['success'] !='')
    {
        echo '<h2>'.$_SESSION['success'].'</h2>';
        unset($_SESSION['success']);
    }

    if(isset($_SESSION['status']) && $_SESSION['status'] !='')
    {
        echo '<h2>'.$_SESSION['status'].'</h2>';
        unset($_SESSION['status']);
    }

    ?>

     <!-- Table Of Content-->

    <div class="table-responsive">


    <?php
       
        $query= "SELECT*FROM users";
        $query_run = mysqli_query($connection, $query);
    ?>

        <table class="table table-bordered table-striped" id="dataTable" widht="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>NIP</th>
                    <th>Nama</th>
                    <th>Jabatan</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>status</th>
                    <th>Level</th>
                    <th>Edit</th>
                    <th>Hapus</th>
                </tr>
            </thead>
            <tbody>

            <?php
            if(mysqli_num_rows($query_run)> 0)
            {
                while($_row=mysqli_fetch_assoc($query_run))
                {

                    ?>

                <tr>
                   <td><?php echo $_row['nip'];?></td>
                   <td><?php echo $_row['nama'];?></td>
                   <td><?php echo $_row['jabatan'];?></td>
                   <td><?php echo $_row['username'];?></td>
                   <td><?php echo $_row['password'];?></td>
                   <td><?php echo $_row['status'];?></td>
                   <td><?php echo $_row['level'];?></td>
                   <td>
                       <form action= "register_edit.php" method="POST">
                           <input type="hidden" name="edit_nip" value="<?php echo $_row['nip'];?>">
                           <button type="submit" name="edit_btn" class="btn btn-success">EDIT</button>
                        </form> 
                       
                    </td>
                    <td>
                        <form action="delete.php" method="POST">
                        <input type="hidden" name="delete-nip" value="<?php echo $_row['nip'];?>">
                        <button type="submit" name="delete-btn" class="btn btn-danger">HAPUS</button>
                        </form>
                    </td>
                </tr>
                
                <?php
                    }
            }
            else{
                echo "Data Gagal Ditambahkan";
            }
                ?>
            </tbody>
        </table>
    </div>
</div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>
