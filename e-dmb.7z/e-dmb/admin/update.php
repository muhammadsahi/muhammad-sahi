<?php
session_start();
include('security.php');

if(isset($_POST['update_btn']))
{
    $nip = $_POST['edit_nip'];
    $nama = $_POST['edit_nama'];
    $jabatan = $_POST['edit_jabatan'];
    $username = $_POST['edit_username'];
    $password = $_POST['edit_password'];
    $status = $_POST['edit_status'];
    $level = $_POST['edit_level'];

    $query= "UPDATE users SET  nama='$nama', jabatan='$jabatan', username='$username', password='$password', status='$status', level='$level' WHERE nip='$nip'";
    $query_run= mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Data Berhasil Diperbarui!";
        header('location: register.php');
    }
    else
    {
        $_SESSION['status'] = "Data Tidak Berhasil Diperbarui!";
        header('location: register.php');
    }
}

?>