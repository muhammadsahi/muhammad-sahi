<?php
include('security.php');

if(isset($_POST['delete-nip']))
{
    $nip= $_POST['delete-nip'];

    $query="DELETE  FROM users WHERE nip='$nip'";
    $query_run= mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Data Berhasil Dihapus!";
        header('location: register.php');
    }
    else
    {
        $_SESSION['status'] = "Data Tidak Berhasil Dihapus!";
        header('location: register.php');
    }
}

?>