<?php
include('security.php');


if(isset($_POST['delete2-entry']))
{
   
    $hari= $_POST['hari'];
  
    $query="TRUNCATE TABLE export_entry ";
    $query_run= mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Data Berhasil Dihapus!";
        header('location: data_entry.php');
    }
    else
    {
        $_SESSION['status'] = "Data Tidak Berhasil Dihapus!";
        header('location: data_entry.php');
    }
}


?>