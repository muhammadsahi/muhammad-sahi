<?php
include('security.php');
include('excel_reader2.php');

?>



<?php

$target = basename($_FILES['fileexcel']['name']);
move_uploaded_file($_FILES['fileexcel']['tmp_name'], $target);

chmod($_FILES['fileexcel']['name'],0777);

$data = new  Spreadsheet_Excel_Reader($_FILES['fileexcel']['name'], false);
$jumlah_baris= $data->rowcount($sheet_index=0);
$berhasil= 0;

for ($i=2; $i<=$jumlah_baris; $i++)
{
    $HARI_CENTER_MEETING  = $data->val($i, 1);
    $TANGGAL_TAGIHAN  = $data->val($i, 2);
    $CABANG  = $data->val($i, 3);
    $KDWIL  = $data->val($i, 4);
    $KD_UNIT  = $data->val($i, 5);
    $KD_CENTER  = $data->val($i, 6);
    $NAMA_UNIT  = $data->val($i, 7);
    $NAMA_CENTER  = $data->val($i, 8);

    if($HARI_CENTER_MEETING !="" && $TANGGAL_TAGIHAN !="" && $CABANG !="" && $KDWIL !="" && $KD_UNIT !="" && $KD_CENTER !="" && $NAMA_UNIT !="" && $NAMA_CENTER !="")
    {
        $query="INSERT INTO data_entry values ('','$HARI_CENTER_MEETING', '$TANGGAL_TAGIHAN', '$CABANG', '$KDWIL', '$KD_UNIT', '$KD_CENTER', '$NAMA_UNIT', '$NAMA_CENTER')";
        $query_run = mysqli_query($connection,$query);
        $berhasil++;
    }
}

unlink($_FILES['fileexcel']['name']);

header ("location: data_entry.php?berhasil=$berhasil");


?>