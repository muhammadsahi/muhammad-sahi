<?php
include('security.php');

 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/content.php');
 ?>

<div class="container-fluid">

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Admin profile</h6>
    </div>

    <div class="card-body">

    <?php



        if(isset($_POST['edit_btn']))
        {
            $nip = $_POST['edit_nip'];
    
            $query= "SELECT * FROM users WHERE nip='$nip' ";
            $query_run = mysqli_query($connection,$query);

            foreach($query_run as $row)
            {
                ?>

                <form action="update.php" method="post">                

                
                <div class="form-group">
                    <label>NIP</label>
                    <input type="text" name="edit_nip" value="<?php echo $row['nip'] ?>"  class="form-control" placeholder="Masukkan Nip" required>
                </div>
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="edit_nama" value="<?php echo $row['nama'] ?>"  class="form-control" placeholder="Masukkan Nama" required>
                </div>
                <div class="form-group">
                    <label>Jabatan</label>
                    <input type="text" name="edit_jabatan" value="<?php echo $row['jabatan'] ?>"  class="form-control" placeholder="Nama Jabatan"required>
                </div>
                <div class="form-group">
                    <label>Username</label>
                    <input type="username" name="edit_username" value="<?php echo $row['username'] ?>"  class="form-control" placeholder="NIP"required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="text" name="edit_password" value="<?php echo $row['password'] ?>" class="form-control" placeholder="Masukkan Password"required>
                </div>
                <div class="form-group">
                    <label>Staus</label>
                    <input type="text" name="edit_hp" value="<?php echo $row['status'] ?>"  class="form-control" placeholder="Masukkan Status"required>
                </div>
                <div class="form-group">
                <label>Select Level</label>
                    <select class="form-control" name="edit_level" >
                        <option value="<?php echo $row['level'] ?>"><?php echo $row['level'] ?></option>
                        <option value="admin">Administrator</option>
                        <option value="operator">Operator</option>
                    </select>
                </div>
                <a href="register.php" class="btn btn-danger"> CANCEL </a>
                <button type="submit" name="update_btn" class ="btn btn-primary"> UPDATE </button>

                </form>

                <?php
            }
        }
    ?>
    </div>
  </div>
</div>


</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>