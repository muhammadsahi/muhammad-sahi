<?php
include('security.php');

        if(isset($_POST['delete'])){
            $id = $_POST['userid'];
            for($i=0;$i<count($id);$i++){
                $del_id = $id[$i];
                $query= "SELECT * FROM data_entry WHERE id='".$del_id."'";
                $query_run= mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Data Berhasil Dihapus!";
        header('location: data_entry.php');
    }
    else
    {
        $_SESSION['status'] = "Data Tidak Berhasil Dihapus!";
        header('location: data_entry.php');
    }
            }
        }

        

?>