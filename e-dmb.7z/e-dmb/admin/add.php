<?php
session_start();

include('security.php');

if(isset($_POST['registerbtn'])){
    $nip = $_POST['nip'];
    $nama = $_POST['nama'];
    $jabatan = $_POST['jabatan'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $status = $_POST['status'];
    $level=$_POST['level'];

    $query= "INSERT INTO users (nip,nama,jabatan,username,password,status,level) VALUES ('$nip','$nama','$jabatan','$username','$password','$status','$level')";
    $query_run = mysqli_query($connection,$query);

    if($query_run)
{
    //echo "Saved";
    $_SESSION['success'] = "Data Berhasil Disimpan!";
    header('Location: register.php');
}
else
{
    $_SESSION['status'] = "Data Berhasil Disimpan!";
    header('Location: register.php');
}
}




?>