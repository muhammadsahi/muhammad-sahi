<?php
include('security.php');

$errorlevel=error_reporting();
if($errorlevel){
    $_SESSION['success']= "Tidak Ada Data Yang Dipilih !";
    header('location: data_entry.php');
}
    $id = $_POST['id_entry'];
    $con=count ($_POST['id_entry']);
    $sho= json_encode($_POST['id_entry']);
    

    for ($i=0; $i < $con; $i++) {
        mysqli_query($connection, " INSERT INTO export_entry (id_entry)  VALUES ('$id[$i]')");

        if(isset($_POST['submit-enrty']))
        {
            $_SESSION['success'] = "Data Berhasil Di Submit!";
            header('location: data_entry.php');
        }
        
    }
    
    

    
    ?>



   


