<?php
 include('security.php');

 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/content.php');
 ?>


<div class="container-fluid">

<div class="card shadow mb-4">
    <div class="card-header py-3">
    <H5>Off Payment</H5>
    
    </div>


<div class="card-body">


<?php
    if(isset($_SESSION['success']) && $_SESSION['success'] !='')
    {
        echo '<h2>'.$_SESSION['success'].'</h2>';
        unset($_SESSION['success']);
    }

    if(isset($_SESSION['status']) && $_SESSION['status'] !='')
    {
        echo '<h2>'.$_SESSION['status'].'</h2>';
        unset($_SESSION['status']);                                                                                                                                                                                                                                                                                                                                                                                             
    }

    ?>                                                                                                                           
    

 <!-- Table Of Content-->

 <div class="table-responsive">
 <form action="coba.php" method="post">
    <table class="table table-bordered" id="dataTable" widht="100%" cellspacing="0" role="grid">
        <thead>
            <tr>
                <th style="font-size: 14px; color: black;">NO</th>
                <th style="font-size: 14px; color: black;"> HARI.CENTER.MEETING</th>
                <th style="font-size: 14px; color: black;">TANGGAL.TAGIHAN</th>
                <th style="font-size: 14px; color: black;">CABANG</th>
                <th style="font-size: 14px; color: black;">KDWIL</th>
                <th style="font-size: 14px; color: black;">KD.UNIT</th>
                <th style="font-size: 14px; color: black;">KD.CENTER</th>
                <th style="font-size: 14px; color: black;">NAMA.UNIT</th>
                <th style="font-size: 14px; color: black;">NAMA.CENTER</th>
                <th style="font-size: 14px; color: black;">STATUS</th>
                
            </tr>
        </thead>
        
        <tbody>
        
      
        
        <?php
        $no="1";
        if(isset($_POST['cari']))
        {
            $search= $_POST['search'];

            $query= "SELECT * FROM data_entry WHERE HARI_CENTER_MEETING LIKE '%$search%' OR TANGGAL_TAGIHAN LIKE '%$search%' OR CABANG LIKE '%$search%' OR KDWIL LIKE '%$search%' OR KD_UNIT LIKE '%$search%' OR KD_CENTER LIKE '%$search%' OR NAMA_UNIT LIKE '%$search%' OR NAMA_UNIT LIKE '%$search%' ORDER BY id ASC";
            
        }
        else {
            $query= "SELECT * FROM data_entry";
        }
        $result=mysqli_query($connection, $query);
        if(!$result){
            echo "connection failed";
        }
        while($_row=mysqli_fetch_assoc($result)){

                ?>
             
            <tr> 
               
               <td style="font-size: 12px; color: black; vertical-align: bottom;"> <?php echo $no++ ?></td>
               <td style="font-size: 12px; color: black; vertical-align: bottom;"> <?php echo $_row['HARI_CENTER_MEETING'];?></td>
               <td style="font-size: 12px; color: black; vertical-align: bottom;"> <?php echo $_row['TANGGAL_TAGIHAN'];?></td>
               <td style="font-size: 12px; color: black; vertical-align: bottom;"> <?php echo $_row['CABANG'];?></td>
               <td style="font-size: 12px; color: black; vertical-align: bottom;"> <?php echo $_row['KDWIL'];?></td>
               <td style="font-size: 12px; color: black; vertical-align: bottom;"> <?php echo $_row['KD_UNIT'];?></td>
               <td style="font-size: 12px; color: black; vertical-align: bottom;"> <?php echo $_row['KD_CENTER'];?></td>
               <td style="font-size: 12px; color: black; vertical-align: bottom;"> <?php echo $_row['NAMA_UNIT'];?></td>
               <td style="font-size: 12px; color: black; vertical-align: bottom;"> <?php echo $_row['NAMA_CENTER'];?></td>
               <td> <input style="display:inline-block; position:relative; width: 50px; height:25px;"  type="checkbox"   value="<?php echo $_row['id_entry'];?>" name="id_entry[]"></td>
                          
                 
            </tr>
            
            <?php
                }
            ?>

        </tbody>
         
    </table>
                
        
         <button type="submit"  name="submit-enrty" class="btn btn-info">SUBMIT</button>
        </form>
</div>
</div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>