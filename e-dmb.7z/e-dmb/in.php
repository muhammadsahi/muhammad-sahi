<?php
session_start();
include('config.php');


    $username_login= $_POST['username'];
    $password_login= $_POST['password'];
    $tanggal= date('Y-m-d H:i:sa');

    $query= mysqli_query($connection,"SELECT * FROM users WHERE username='$username_login' AND password='$password_login'");

    $cek= mysqli_num_rows($query);

    if($cek > 0){
        $data= mysqli_fetch_assoc($query);
    
    if($data ['level']== "admin") {
        $update = mysqli_query($connection, "UPDATE users SET status= '1', terakhir_login= '$tanggal' WHERE username= '$username_login'");
        if($update){
            $_SESSION['username'] = $username_login;
            $_SESSION['level']= $data['level'];
            $_SESSION['nama']= $data['nama'];
            
            header("location: admin/index.php");

        }
        else{

            header("location: index.php?pesan=gagal");
        }
    }elseif ($data['level']=="operator") {
        $_SESSION['username']= $username_login;
        $_SESSION['level']= "operator";
        $_SESSION['nama']= $data['nama'];
        header("location: guest/index.php");
    }elseif ($data['level']=="operator") {
        $_SESSION['username']= $username_login;
        $_SESSION['level']= "user";
        $_SESSION['nama']= $data['nama'];
        header("location: guest/index.php");
    }
    else{
        header("location: index.php?pesan=gagal");
    }
}else{
    header("location: index.php?pesan=gagal");
}
    


?>