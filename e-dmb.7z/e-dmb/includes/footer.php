
   <!-- Footer -->
   <footer class="sticky-footer bg-white">
        <div class="container my-auto">
        <div class="lockscreen-footer text-center">
            Copyright &copy; 2020 E- Dana Mandiri Bogor <b>(E- DMB)</b>
            <br> All rights reserved<br>
            <b>Version</b> 1.0
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->
    

</body>



</html>
