<?php

$server_name="localhost";
$username="root";
$password="";
$dbname="audit";

$connection=mysqli_connect("$server_name", "$username", "$password", "$dbname");
$dbconfig=mysqli_select_db($connection, $dbname);

if($dbconfig)
{
   // echo "connected";
}
else
{
    echo "database not connected";
}


?>